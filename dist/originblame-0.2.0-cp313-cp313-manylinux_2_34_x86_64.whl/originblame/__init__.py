from .originblame import *

__doc__ = originblame.__doc__
if hasattr(originblame, "__all__"):
    __all__ = originblame.__all__